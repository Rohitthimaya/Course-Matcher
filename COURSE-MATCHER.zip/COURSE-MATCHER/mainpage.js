document.getElementById("signOutBtn").addEventListener("click", function () {
  document.getElementById("signOutForm").submit();
});